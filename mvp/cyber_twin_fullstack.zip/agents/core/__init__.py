"""Shared agent runtime primitives."""
